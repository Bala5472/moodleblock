<?php
$string['pluginname'] = 'Moodle test block';
$string['moodleblock'] = 'Moodle test block';
$string['moodleblock:addinstance'] = 'Add a new simple HTML block';
$string['moodleblock:myaddinstance'] = 'Add a new simple HTML block to the My Moodle page';